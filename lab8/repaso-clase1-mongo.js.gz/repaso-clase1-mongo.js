// Ejercicio 1
db.users.insertMany([
    {
        "name" : "user1",
        "email" : "user1@gmail.com",
        "password" : "$2b$12$URuser1qGNK0LzO0HM/jLhgUCNNIJ9RJAqMUQ74crlJ1Vu"
    },
    {
        "name" : "user2",
        "email" : "user2@gmail.com",
        "password" : "$2b$12$URuser2qGNK0LzO0HM/jLhgUCNNIJ9RJAqMUQ74crlJ1Vu"
    },
    {
        "name" : "user3",
        "email" : "user3@gmail.com",
        "password" : "$2b$12$URuser3qGNK0LzO0HM/jLhgUCNNIJ9RJAqMUQ74crlJ1Vu"
    },
    {
        "name" : "user4",
        "email" : "user4@gmail.com",
        "password" : "$2b$12$URuser4qGNK0LzO0HM/jLhgUCNNIJ9RJAqMUQ74crlJ1Vu"
    },
    {
        "name" : "user5",
        "email" : "user5@gmail.com",
        "password" : "$2b$12$URuser5qGNK0LzO0HM/jLhgUCNNIJ9RJAqMUQ74crlJ1Vu"
    },
])

db.comments.insertMany([
    {
        "name" : "user1",
        "email" : "user1@gmail.com",
        "movie_id" : ObjectId("573a1390f29313caabcd418c"),
        "text" : "Muy buena! 1",
        "date" : new Date(),
    },
    {
        "name" : "user2",
        "email" : "user2@gmail.com",
        "movie_id" : ObjectId("573a1390f29313caabcd418c"),
        "text" : "Muy buena! 2",
        "date" : new Date()
    },
    {
        "name" : "user3",
        "email" : "user3@gmail.com",
        "movie_id" : ObjectId("573a1390f29313caabcd418c"),
        "text" : "Muy buena! 3",
        "date" : new Date()
    },
    {
        "name" : "user4",
        "email" : "user4@gmail.com",
        "movie_id" : ObjectId("573a1390f29313caabcd418c"),
        "text" : "Muy buena! 4",
        "date" : new Date(),
    },
    {
        "name" : "user5",
        "email" : "user5gmail.com",
        "movie_id" : ObjectId("573a1390f29313caabcd418c"),
        "text" : "Muy buena! 5",
        "date" : new Date(),
    }
])


// Ejercicio 2
db.movies.find(
    { "imdb.rating": { $type: "double" }, "year": { $gte: 1990, $lt: 2000 } },
    { "title": 1, "year": 1, "cast": 1, "directors": 1, "imdb.rating": 1 }
).sort({"imdb.rating": -1}).limit(10)


// Ejercicio 5
db.movies.find(
    {
        "genres": { $all: [ "Drama", "Action" ] },
        "languages": { $size: 1 },
        "imdb.votes": { $type: "int"},
        $or: [ { "imdb.rating": { $type: "double", $gte: 9 } }, { "runtime": { $gte: 180 } } ]
    },
    {"title": 1, "languages": 1, "genres": 1, "released": 1, "imdb.votes": 1}
).sort({"released": -1, "votes": -1})
